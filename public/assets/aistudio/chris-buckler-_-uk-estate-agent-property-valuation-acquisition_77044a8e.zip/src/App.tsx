/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ChallengeSection } from './components/ChallengeSection';
import { SolutionSection } from './components/SolutionSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { BenefitsSection } from './components/BenefitsSection';
import { VisualShowcase } from './components/VisualShowcase';
import { ValuationCalculator } from './components/ValuationCalculator';
import { AboutChrisSection } from './components/AboutChrisSection';
import { TrustProofSection } from './components/TrustProofSection';
import { FaqSection } from './components/FaqSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [initialInterestNote, setInitialInterestNote] = useState('');

  const handleOpenBooking = (interestNote = '') => {
    setInitialInterestNote(interestNote);
    setIsBookingOpen(true);
  };

  const handleCloseBooking = () => {
    setIsBookingOpen(false);
    setInitialInterestNote('');
  };

  return (
    <div className="min-h-screen bg-[#0B1423] text-[#F8F7F3] selection:bg-[#0E827C] selection:text-white relative">
      {/* Top Header with 3-zone contract */}
      <Header onOpenBooking={() => handleOpenBooking('Header CTA - Discovery Call')} />

      <main>
        {/* Section 2: Extraordinary Hero Section */}
        <Hero onOpenBooking={() => handleOpenBooking('Hero CTA - Discovery Call')} />

        {/* Section 3: The Challenge */}
        <ChallengeSection />

        {/* Section 4: The Solution */}
        <SolutionSection onOpenBooking={() => handleOpenBooking('Solution Section - Territory Check')} />

        {/* Section 5: How It Works */}
        <HowItWorksSection onOpenBooking={() => handleOpenBooking('How It Works - Postcode Discussion')} />

        {/* Section 6: Key Benefits */}
        <BenefitsSection />

        {/* Section 7: Visual Showcase (Valuer Diary & Dossier Interface) */}
        <VisualShowcase />

        {/* Interactive Pipeline & Revenue Calculator */}
        <ValuationCalculator onOpenBooking={() => handleOpenBooking('Calculator - Pipeline Potential Review')} />

        {/* Section 8: Why Choose Chris (Credibility & Background) */}
        <AboutChrisSection onOpenBooking={() => handleOpenBooking('About Chris - 1-to-1 Consultation')} />

        {/* Section 9: Trust & Credibility (UK Agency Transformation Frameworks) */}
        <TrustProofSection />

        {/* Section 10: FAQ */}
        <FaqSection onOpenBooking={() => handleOpenBooking('FAQ - Direct Inquiry')} />

        {/* Section 11: Premium Final CTA */}
        <FinalCtaSection onOpenBooking={() => handleOpenBooking('Final CTA - Strategy Session')} />
      </main>

      {/* Section 12: Footer */}
      <Footer onOpenBooking={() => handleOpenBooking('Footer - Postcode Verification')} />

      {/* Interactive Discovery Call Booking Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={handleCloseBooking}
        initialInterest={initialInterestNote}
      />
    </div>
  );
}
