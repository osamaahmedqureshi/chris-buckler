export interface ValuationAppointment {
  id: string;
  propertyTitle: string;
  postcode: string;
  propertyType: 'Detached' | 'Semi-Detached' | 'Terraced' | 'Penthouse' | 'Period Townhouse';
  estimatedGuide: string;
  vendorMotivation: string;
  timeline: string;
  date: string;
  timeSlot: string;
  status: 'Confirmed' | 'Pending Review' | 'Completed';
  vendorName: string;
  contactNumber: string;
  potentialFee: string;
}

export interface BookingFormState {
  fullName: string;
  agencyName: string;
  email: string;
  phone: string;
  targetPostcodes: string;
  agencyType: string;
  currentValuationsPerMonth: string;
  targetValuationsPerMonth: string;
  preferredDate: string;
  preferredTime: string;
  notes: string;
}
