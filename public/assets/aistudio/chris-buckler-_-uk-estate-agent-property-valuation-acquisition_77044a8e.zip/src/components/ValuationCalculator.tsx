import React, { useState } from 'react';
import { Calculator, ArrowRight, PoundSterling, TrendingUp, Sparkles } from 'lucide-react';

interface ValuationCalculatorProps {
  onOpenBooking: () => void;
}

export const ValuationCalculator: React.FC<ValuationCalculatorProps> = ({ onOpenBooking }) => {
  const [avgPrice, setAvgPrice] = useState(750000);
  const [feePercent, setFeePercent] = useState(1.5);
  const [extraValuations, setExtraValuations] = useState(10);
  const [conversionRate, setConversionRate] = useState(30);

  // Calculations
  const feePerSale = (avgPrice * (feePercent / 100));
  const newInstructionsPerMonth = (extraValuations * (conversionRate / 100));
  const monthlyRevenuePotential = newInstructionsPerMonth * feePerSale;
  const annualRevenuePotential = monthlyRevenuePotential * 12;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <section className="py-20 bg-[#0B1423] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#101C30] to-[#0E1A2B] border border-[#1E3352] rounded-3xl p-6 sm:p-10 lg:p-12 shadow-2xl">
          <div className="max-w-3xl mb-10">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-3">
              <span>Interactive Revenue Model</span>
              <span aria-hidden="true">·</span>
              <span>Calculate Your Return</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#F8F7F3]">
              What Would 10 More Qualified Valuations Mean for{' '}
              <span className="font-editorial italic font-normal text-[#C9A66B]">
                Your Agency’s Fee Revenue?
              </span>
            </h2>
            <p className="mt-3 text-sm sm:text-base text-[#94A3B8]">
              Adjust the sliders below to match your agency’s average selling price, typical commission fee,
              and expected instruction conversion rate.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Sliders Area */}
            <div className="lg:col-span-7 space-y-6">
              {/* Slider 1: Average Property Price */}
              <div className="space-y-2 bg-[#0B1423] p-4 sm:p-5 rounded-xl border border-[#1E3352]/80">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-[#F8F7F3] font-medium">Average Sale Price in Your Patch</span>
                  <span className="text-[#C9A66B] font-mono font-bold text-base">
                    {formatCurrency(avgPrice)}
                  </span>
                </div>
                <input
                  type="range"
                  min="300000"
                  max="2500000"
                  step="25000"
                  value={avgPrice}
                  onChange={(e) => setAvgPrice(Number(e.target.value))}
                  className="w-full h-2 bg-[#1E3352] rounded-lg appearance-none cursor-pointer accent-[#0E827C]"
                />
                <div className="flex justify-between text-[11px] text-[#718096]">
                  <span>£300,000 (UK Regional)</span>
                  <span>£1,250,000 (Prime Outer)</span>
                  <span>£2,500,000+ (Prime London)</span>
                </div>
              </div>

              {/* Slider 2: Average Commission Rate */}
              <div className="space-y-2 bg-[#0B1423] p-4 sm:p-5 rounded-xl border border-[#1E3352]/80">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-[#F8F7F3] font-medium">Standard Agency Sole Fee</span>
                  <span className="text-[#0E827C] font-mono font-bold text-base">
                    {feePercent.toFixed(1)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="2.5"
                  step="0.1"
                  value={feePercent}
                  onChange={(e) => setFeePercent(Number(e.target.value))}
                  className="w-full h-2 bg-[#1E3352] rounded-lg appearance-none cursor-pointer accent-[#0E827C]"
                />
                <div className="flex justify-between text-[11px] text-[#718096]">
                  <span>1.0%</span>
                  <span>1.5% (Typical UK Sole)</span>
                  <span>2.5% (Bespoke / Multi-Agent)</span>
                </div>
              </div>

              {/* Slider 3: Additional Monthly Valuations */}
              <div className="space-y-2 bg-[#0B1423] p-4 sm:p-5 rounded-xl border border-[#1E3352]/80">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-[#F8F7F3] font-medium">Additional Valuations Booked / Month</span>
                  <span className="text-white font-mono font-bold text-base">
                    +{extraValuations} Appraisals
                  </span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="25"
                  step="1"
                  value={extraValuations}
                  onChange={(e) => setExtraValuations(Number(e.target.value))}
                  className="w-full h-2 bg-[#1E3352] rounded-lg appearance-none cursor-pointer accent-[#0E827C]"
                />
                <div className="flex justify-between text-[11px] text-[#718096]">
                  <span>+4 / month</span>
                  <span>+10 / month</span>
                  <span>+25 / month</span>
                </div>
              </div>

              {/* Slider 4: Pitch Conversion Rate */}
              <div className="space-y-2 bg-[#0B1423] p-4 sm:p-5 rounded-xl border border-[#1E3352]/80">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-[#F8F7F3] font-medium">Your Valuation-to-Instruction Win Rate</span>
                  <span className="text-[#DFBA7D] font-mono font-bold text-base">
                    {conversionRate}%
                  </span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="50"
                  step="5"
                  value={conversionRate}
                  onChange={(e) => setConversionRate(Number(e.target.value))}
                  className="w-full h-2 bg-[#1E3352] rounded-lg appearance-none cursor-pointer accent-[#0E827C]"
                />
                <div className="flex justify-between text-[11px] text-[#718096]">
                  <span>15% Conservative</span>
                  <span>30% Industry Benchmark</span>
                  <span>50% Elite Closer</span>
                </div>
              </div>
            </div>

            {/* Results Showcase Card */}
            <div className="lg:col-span-5 bg-[#0B1423] border border-[#1E3352] rounded-2xl p-6 sm:p-8 space-y-6 text-center lg:text-left">
              <div className="space-y-1">
                <span className="text-xs uppercase tracking-wider text-[#C9A66B] font-semibold">
                  Estimated Agency Commission Pipeline
                </span>
                <div className="pt-2">
                  <span className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F8F7F3] font-mono block">
                    {formatCurrency(annualRevenuePotential)}
                  </span>
                  <span className="text-xs text-[#0E827C] font-medium block mt-1">
                    Potential Additional Annual Fee Income
                  </span>
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-[#1E3352]/80 text-xs">
                <div className="flex justify-between py-1.5 border-b border-[#1E3352]/50">
                  <span className="text-[#94A3B8]">Est. New Instructions Won:</span>
                  <span className="text-white font-mono font-semibold">
                    ~{newInstructionsPerMonth.toFixed(1)} listings / mo
                  </span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#1E3352]/50">
                  <span className="text-[#94A3B8]">Average Fee per Completed Instruction:</span>
                  <span className="text-[#C9A66B] font-mono font-semibold">
                    {formatCurrency(feePerSale)}
                  </span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-[#94A3B8]">Monthly Incremental Value:</span>
                  <span className="text-[#0E827C] font-mono font-semibold">
                    {formatCurrency(monthlyRevenuePotential)} / mo
                  </span>
                </div>
              </div>

              <div className="pt-3">
                <button
                  onClick={onOpenBooking}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-[#0E827C] hover:bg-[#129E97] text-white font-semibold text-sm transition-all shadow-lg shadow-[#0E827C]/20 cursor-pointer"
                >
                  <span>Build This Pipeline for Your Agency</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[11px] text-[#718096] text-center mt-2.5">
                  Model provided for illustrative planning. Results depend on local stock and agency close rates.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
