import React from 'react';
import { TrendingDown, UserX, AlertCircle, Compass } from 'lucide-react';

export const ChallengeSection: React.FC = () => {
  const challenges = [
    {
      icon: TrendingDown,
      title: 'Inconsistent Valuation Enquiries',
      description:
        'The exhausting feast-or-famine cycle where one month your valuation diary is full, and the next month your senior valuers are waiting for the phone to ring.',
      impact: 'Unpredictable cash flow and lost fee momentum',
    },
    {
      icon: UserX,
      title: 'Time Lost Chasing Cold Leads',
      description:
        'Valuable hours wasted distributing blanket leaflet drops or following up generic portal valuation tool enquiries where the homeowner was simply curious.',
      impact: 'High marketing spend with low instruction return',
    },
    {
      icon: AlertCircle,
      title: 'Difficulty Maintaining a Predictable Pipeline',
      description:
        'Without a dedicated homeowner acquisition system, forecasting instruction volumes 60 to 90 days ahead feels like guesswork rather than controlled agency growth.',
      impact: 'Restricted business planning and team stress',
    },
    {
      icon: Compass,
      title: 'Intense Local Competition for Instructions',
      description:
        'Local competitors and aggressive corporate chains competing for the same few active instructions, putting downward pressure on your hard-earned commission rates.',
      impact: 'Fee erosion and reduced listing margins',
    },
  ];

  return (
    <section id="challenge" className="py-20 sm:py-28 bg-[#0E1A2B] border-y border-[#1E3352]/70 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-3">
            <span>The Agency Reality</span>
            <span aria-hidden="true">·</span>
            <span>UK Property Market Pressures</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
            Great Estate Agents Deserve{' '}
            <span className="font-editorial italic font-normal text-[#C9A66B]">
              More Valuation Opportunities.
            </span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#94A3B8] leading-relaxed">
            Winning instructions is what you do best. But relying on passive portal referrals, 
            door-to-door flyers, or sporadic word-of-mouth leaves your agency's pipeline vulnerable.
          </p>
        </div>

        {/* 4 Elegant Problem Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {challenges.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="bg-[#101C30] border border-[#1E3352] rounded-2xl p-7 sm:p-8 hover:border-[#0E827C]/50 transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-xl bg-[#0B1423] border border-[#1E3352] flex items-center justify-center text-[#C9A66B] group-hover:text-[#0E827C] group-hover:border-[#0E827C]/40 transition-colors">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-mono text-[#718096]">
                      0{idx + 1}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-[#F8F7F3] mb-3 group-hover:text-white transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-sm text-[#94A3B8] leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#1E3352]/70 flex items-center justify-between text-xs">
                  <span className="text-[#718096]">Consequence:</span>
                  <span className="text-[#DFBA7D] font-medium">{item.impact}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Transitional bridge to solution */}
        <div className="mt-14 p-6 sm:p-8 bg-[#132238] border border-[#1E3352] rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-lg font-bold text-[#F8F7F3]">
              There is a more predictable, high-value way to generate valuations.
            </h4>
            <p className="text-sm text-[#94A3B8]">
              Connect with motivated local sellers before they list on general portals.
            </p>
          </div>
          <a
            href="#solution"
            className="px-6 py-3 rounded-xl bg-[#0E827C] hover:bg-[#129E97] text-white font-semibold text-sm transition-colors whitespace-nowrap shrink-0"
          >
            Explore The Solution
          </a>
        </div>
      </div>
    </section>
  );
};
