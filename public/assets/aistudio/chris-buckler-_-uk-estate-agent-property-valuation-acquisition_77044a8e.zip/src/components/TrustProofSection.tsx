import React from 'react';
import { ShieldCheck, MapPin, CheckCircle, ArrowUpRight, Sparkles } from 'lucide-react';

export const TrustProofSection: React.FC = () => {
  const caseFrameworks = [
    {
      agencyProfile: 'Independent Estate Agency (Surrey & Home Counties)',
      initialState: 'Struggling with leaflet fatigue and inconsistent monthly valuations (averaging 4–6/mo).',
      outcomeModel: 'Scaled to 16+ pre-qualified valuation appointments monthly; secured 6 prime instructions in first quarter.',
      territory: 'KT & GU Postcode Sectors',
      highlightMetric: '+185% Inbound Appraisals',
    },
    {
      agencyProfile: 'Boutique Prime Specialist (South West London)',
      initialState: 'Over-reliant on portal recommendations and high street passersby for £1m+ stock.',
      outcomeModel: 'Introduced direct off-market vendor campaigns securing instructions at 1.75% sole agency fee.',
      territory: 'SW13, SW14 & SW19 Sectors',
      highlightMetric: '£1.6M Avg Property Bracket',
    },
    {
      agencyProfile: 'Regional Multi-Branch Practice (Thames Valley)',
      initialState: 'High valuer downtime across 2 branch offices during mid-season transition.',
      outcomeModel: 'Unified diary booking system delivering a continuous stream of vendor appointments across both branches.',
      territory: 'RG & SL Postcode Sectors',
      highlightMetric: '100% Diary Utilization',
    },
  ];

  return (
    <section className="py-20 sm:py-28 bg-[#0B1423] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-3">
              <span>Agency Transformation Scenarios</span>
              <span aria-hidden="true">·</span>
              <span>Proven Methodologies</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
              Designed for Real UK Agency Operations,{' '}
              <span className="font-editorial italic font-normal text-[#C9A66B]">
                Not Hypothetical Marketing.
              </span>
            </h2>
            <p className="mt-4 text-base text-[#94A3B8]">
              Here is how different agency models unlock reliable valuation volume without sacrificing brand reputation.
            </p>
          </div>

          <div className="text-xs text-[#718096] bg-[#101C30] border border-[#1E3352] p-3 rounded-xl max-w-xs">
            <span className="text-[#C9A66B] font-semibold block mb-0.5">Verified Case Frameworks</span>
            Specific client testimonials are showcased during your confidential 1-to-1 consultation.
          </div>
        </div>

        {/* UK Aerial Neighborhood Image Feature Banner */}
        <div className="relative rounded-2xl overflow-hidden border border-[#1E3352] mb-12 shadow-2xl">
          <div className="aspect-[21/9] sm:aspect-[24/8] relative">
            <img
              src="/src/assets/images/uk_neighbourhood_aerial_1792503664400.jpg"
              alt="Affluent UK residential suburb neighbourhood with high transaction volume"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0B1423] via-[#0B1423]/70 to-transparent" />
          </div>

          <div className="absolute inset-0 p-6 sm:p-10 flex flex-col justify-center max-w-xl text-left">
            <span className="text-xs uppercase tracking-wider text-[#C9A66B] font-semibold">
              Local Territory Focus
            </span>
            <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold text-white mt-1">
              Every Affluent Street Contains Homeowners Planning Their Move.
            </h3>
            <p className="text-xs sm:text-sm text-[#94A3B8] mt-2 hidden sm:block">
              We help you identify and connect with those vendors weeks before they contact high-street competitors.
            </p>
          </div>
        </div>

        {/* 3 Case Study Framework Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {caseFrameworks.map((cf) => (
            <div
              key={cf.agencyProfile}
              className="bg-[#101C30] border border-[#1E3352] rounded-2xl p-7 flex flex-col justify-between hover:border-[#0E827C]/50 transition-all"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-[#0E827C] bg-[#0E827C]/15 px-2 py-0.5 rounded border border-[#0E827C]/30">
                    {cf.territory}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#C9A66B]">
                    {cf.highlightMetric}
                  </span>
                </div>

                <h4 className="text-base font-bold text-[#F8F7F3]">
                  {cf.agencyProfile}
                </h4>

                <div className="space-y-3 pt-2 text-xs">
                  <div>
                    <span className="text-[#718096] block uppercase text-[10px] tracking-wider">Before:</span>
                    <p className="text-[#94A3B8] mt-0.5">{cf.initialState}</p>
                  </div>
                  <div>
                    <span className="text-[#0E827C] block uppercase text-[10px] tracking-wider font-semibold">After Implementation:</span>
                    <p className="text-[#F8F7F3] mt-0.5">{cf.outcomeModel}</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#1E3352]/70 flex items-center justify-between text-xs text-[#718096]">
                <span>Strict Postcode Exclusivity</span>
                <ShieldCheck className="w-4 h-4 text-[#0E827C]" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
