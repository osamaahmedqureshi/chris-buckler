import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Home, ArrowUpRight, CheckCircle2, ChevronRight, FileText, Phone } from 'lucide-react';
import type { ValuationAppointment } from '../types';

export const VisualShowcase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'calendar' | 'dossier' | 'pipeline'>('calendar');
  const [selectedAppointmentId, setSelectedAppointmentId] = useState('app-1');

  const appointments: ValuationAppointment[] = [
    {
      id: 'app-1',
      propertyTitle: 'The Cedars, Sandy Lane',
      postcode: 'KT11 2EJ',
      propertyType: 'Detached',
      estimatedGuide: '£1,450,000',
      vendorMotivation: 'Downsizing after children relocated; keen on autumn listing with local boutique agency.',
      timeline: 'Next 30–60 Days',
      date: 'Thursday, 23 Oct',
      timeSlot: '10:30 AM',
      status: 'Confirmed',
      vendorName: 'David & Caroline Thornton',
      contactNumber: '07789 ••••••',
      potentialFee: '£21,750 (at 1.5%)',
    },
    {
      id: 'app-2',
      propertyTitle: '48 St. Peter’s Square',
      postcode: 'W6 9BW',
      propertyType: 'Period Townhouse',
      estimatedGuide: '£1,875,000',
      vendorMotivation: 'Relocating to Gloucestershire for school intake; wants valuation from local prime specialist.',
      timeline: 'Immediate (within 14 days)',
      date: 'Friday, 24 Oct',
      timeSlot: '02:00 PM',
      status: 'Confirmed',
      vendorName: 'Eleanor Vance',
      contactNumber: '07912 ••••••',
      potentialFee: '£28,125 (at 1.5%)',
    },
    {
      id: 'app-3',
      propertyTitle: 'Meadowlands, Mill Lane',
      postcode: 'GU5 9NT',
      propertyType: 'Detached',
      estimatedGuide: '£950,000',
      vendorMotivation: 'Retirement move; seeking advice on guide price positioning and expected marketing duration.',
      timeline: 'Next 60–90 Days',
      date: 'Monday, 27 Oct',
      timeSlot: '11:15 AM',
      status: 'Confirmed',
      vendorName: 'Mark & Sarah Campbell',
      contactNumber: '07801 ••••••',
      potentialFee: '£14,250 (at 1.5%)',
    },
  ];

  const currentAppointment =
    appointments.find((a) => a.id === selectedAppointmentId) || appointments[0];

  return (
    <section id="showcase" className="py-20 sm:py-28 bg-[#0E1A2B] border-t border-[#1E3352]/70 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-3">
              <span>Interactive Workflow Simulation</span>
              <span aria-hidden="true">·</span>
              <span>The Valuer Experience</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
              A Valuer’s Diary That Gives You{' '}
              <span className="font-editorial italic font-normal text-[#C9A66B]">
                Complete Control.
              </span>
            </h2>
            <p className="mt-4 text-base text-[#94A3B8]">
              Explore an illustrative preview of how pre-qualified valuation appointments and vendor dossiers
              arrive directly into your agency’s diary.
            </p>
          </div>

          {/* Interactive Mode Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1.5 bg-[#0B1423] border border-[#1E3352] rounded-xl self-start md:self-end">
            <button
              onClick={() => setActiveTab('calendar')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'calendar'
                  ? 'bg-[#0E827C] text-white shadow-sm'
                  : 'text-[#94A3B8] hover:text-[#F8F7F3]'
              }`}
            >
              Diary & Calendar
            </button>
            <button
              onClick={() => setActiveTab('dossier')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'dossier'
                  ? 'bg-[#0E827C] text-white shadow-sm'
                  : 'text-[#94A3B8] hover:text-[#F8F7F3]'
              }`}
            >
              Vendor Dossier
            </button>
            <button
              onClick={() => setActiveTab('pipeline')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'pipeline'
                  ? 'bg-[#0E827C] text-white shadow-sm'
                  : 'text-[#94A3B8] hover:text-[#F8F7F3]'
              }`}
            >
              Pipeline Forecast
            </button>
          </div>
        </div>

        {/* Interactive Container */}
        <div className="bg-[#101C30] border border-[#1E3352] rounded-2xl p-6 sm:p-8 shadow-2xl">
          {activeTab === 'calendar' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Left Column: Selectable Appointments in Diary */}
              <div className="lg:col-span-5 space-y-3">
                <div className="flex items-center justify-between text-xs text-[#718096] pb-1 border-b border-[#1E3352]/80">
                  <span>Upcoming Market Appraisals</span>
                  <span className="font-mono text-[#0E827C]">3 Booked This Week</span>
                </div>

                {appointments.map((app) => {
                  const isSelected = selectedAppointmentId === app.id;
                  return (
                    <button
                      key={app.id}
                      onClick={() => setSelectedAppointmentId(app.id)}
                      className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#0B1423] border-[#0E827C] shadow-md'
                          : 'bg-[#0B1423]/50 border-[#1E3352]/70 hover:border-[#1E3352]'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-mono text-[#C9A66B] flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5" />
                          {app.date} · {app.timeSlot}
                        </span>
                        <span className="text-[11px] font-semibold text-[#0E827C] bg-[#0E827C]/15 px-2 py-0.5 rounded">
                          {app.status}
                        </span>
                      </div>

                      <h4 className="text-sm font-bold text-[#F8F7F3]">
                        {app.propertyTitle}
                      </h4>

                      <div className="flex items-center justify-between text-xs text-[#718096] mt-2">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-[#0E827C]" />
                          {app.postcode}
                        </span>
                        <span className="font-mono font-semibold text-[#DFBA7D]">
                          {app.estimatedGuide}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Active Appointment Detailed View */}
              <div className="lg:col-span-7 bg-[#0B1423] border border-[#1E3352] rounded-xl p-6 sm:p-7 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1E3352]/80 pb-5">
                  <div>
                    <span className="text-xs uppercase tracking-wider text-[#C9A66B] font-semibold">
                      Confirmed Market Appraisal Slot
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold text-[#F8F7F3] mt-1">
                      {currentAppointment.propertyTitle}
                    </h3>
                    <p className="text-xs text-[#94A3B8] flex items-center gap-1.5 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-[#0E827C]" />
                      <span>{currentAppointment.postcode} · {currentAppointment.propertyType}</span>
                    </p>
                  </div>

                  <div className="text-left sm:text-right">
                    <span className="text-xs text-[#718096] block">Est. Agency Commission</span>
                    <span className="text-lg font-bold text-[#0E827C] font-mono">
                      {currentAppointment.potentialFee}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="bg-[#101C30] p-3.5 rounded-lg border border-[#1E3352]/70 space-y-1">
                    <span className="text-[#718096] block">Vendors / Homeowners</span>
                    <span className="text-[#F8F7F3] font-semibold text-sm flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#C9A66B]" />
                      {currentAppointment.vendorName}
                    </span>
                  </div>

                  <div className="bg-[#101C30] p-3.5 rounded-lg border border-[#1E3352]/70 space-y-1">
                    <span className="text-[#718096] block">Target Move Horizon</span>
                    <span className="text-[#F8F7F3] font-semibold text-sm flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#0E827C]" />
                      {currentAppointment.timeline}
                    </span>
                  </div>
                </div>

                <div className="bg-[#101C30] p-4 rounded-lg border border-[#1E3352]/70 space-y-2">
                  <span className="text-xs font-semibold text-[#C9A66B] uppercase tracking-wider block">
                    Vendor Motivation & Context Notes
                  </span>
                  <p className="text-xs sm:text-sm text-[#94A3B8] leading-relaxed">
                    "{currentAppointment.vendorMotivation}"
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-[#718096] border-t border-[#1E3352]/80">
                  <div className="flex items-center gap-2 text-[#0E827C]">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Homeowner confirmed via calendar invite</span>
                  </div>
                  <span>Valuer Dossier Auto-Generated</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'dossier' && (
            <div className="space-y-6">
              <div className="border-b border-[#1E3352]/80 pb-4">
                <span className="text-xs uppercase tracking-wider text-[#C9A66B] font-semibold">
                  Comprehensive Property & Seller Intelligence
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#F8F7F3] mt-1">
                  Pre-Appraisal Intelligence Pack
                </h3>
                <p className="text-xs sm:text-sm text-[#94A3B8] mt-1">
                  Your valuer walks into the property with genuine competitive advantages.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-[#0B1423] p-5 rounded-xl border border-[#1E3352] space-y-3">
                  <span className="text-xs font-mono text-[#0E827C] uppercase tracking-wider block">
                    1. Property Attributes
                  </span>
                  <ul className="text-xs text-[#94A3B8] space-y-2">
                    <li className="flex justify-between py-1 border-b border-[#1E3352]/50">
                      <span>Square Footage:</span>
                      <span className="text-white font-mono">3,240 sq ft</span>
                    </li>
                    <li className="flex justify-between py-1 border-b border-[#1E3352]/50">
                      <span>Tenure:</span>
                      <span className="text-white">Freehold</span>
                    </li>
                    <li className="flex justify-between py-1 border-b border-[#1E3352]/50">
                      <span>Plot Size:</span>
                      <span className="text-white">0.42 Acres</span>
                    </li>
                    <li className="flex justify-between py-1">
                      <span>Council Tax:</span>
                      <span className="text-white">Band G</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-[#0B1423] p-5 rounded-xl border border-[#1E3352] space-y-3">
                  <span className="text-xs font-mono text-[#C9A66B] uppercase tracking-wider block">
                    2. Vendor Psychological Profile
                  </span>
                  <ul className="text-xs text-[#94A3B8] space-y-2">
                    <li className="flex justify-between py-1 border-b border-[#1E3352]/50">
                      <span>Previous Sale Year:</span>
                      <span className="text-white font-mono">2009 (£785,000)</span>
                    </li>
                    <li className="flex justify-between py-1 border-b border-[#1E3352]/50">
                      <span>Equity Position:</span>
                      <span className="text-emerald-400 font-medium">High (Substantial)</span>
                    </li>
                    <li className="flex justify-between py-1 border-b border-[#1E3352]/50">
                      <span>Key Priority:</span>
                      <span className="text-white">Professional marketing & price discretion</span>
                    </li>
                    <li className="flex justify-between py-1">
                      <span>Chain Status:</span>
                      <span className="text-white">No forward chain pressure</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-[#0B1423] p-5 rounded-xl border border-[#1E3352] space-y-3">
                  <span className="text-xs font-mono text-[#0E827C] uppercase tracking-wider block">
                    3. Local Valuation Angle
                  </span>
                  <p className="text-xs text-[#94A3B8] leading-relaxed">
                    Recent comparable sold at £1.42m on adjacent road. Recommended launch guide: £1.45m – £1.5m to generate competitive bidding from London out-of-area buyers.
                  </p>
                  <div className="pt-2">
                    <span className="text-[11px] text-[#C9A66B] font-medium block">
                      Target Fee: 1.5% Sole Agency
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'pipeline' && (
            <div className="space-y-6">
              <div className="border-b border-[#1E3352]/80 pb-4">
                <span className="text-xs uppercase tracking-wider text-[#C9A66B] font-semibold">
                  Quarterly Territory Performance Model
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#F8F7F3] mt-1">
                  Valuation-to-Instruction Commercial Velocity
                </h3>
                <p className="text-xs sm:text-sm text-[#94A3B8] mt-1">
                  Illustrative pipeline model based on a 15-valuation monthly acquisition run rate.
                </p>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-[#0B1423] p-5 rounded-xl border border-[#1E3352]">
                  <span className="text-xs text-[#718096] block mb-1">Monthly Appraisals</span>
                  <span className="text-2xl sm:text-3xl font-bold text-white font-mono">15</span>
                  <span className="text-[11px] text-[#0E827C] block mt-1">Pre-qualified appointments</span>
                </div>

                <div className="bg-[#0B1423] p-5 rounded-xl border border-[#1E3352]">
                  <span className="text-xs text-[#718096] block mb-1">Instruction Win Rate</span>
                  <span className="text-2xl sm:text-3xl font-bold text-[#C9A66B] font-mono">35%</span>
                  <span className="text-[11px] text-[#718096] block mt-1">5.2 new listings / month</span>
                </div>

                <div className="bg-[#0B1423] p-5 rounded-xl border border-[#1E3352]">
                  <span className="text-xs text-[#718096] block mb-1">Avg Property Value</span>
                  <span className="text-2xl sm:text-3xl font-bold text-white font-mono">£850k</span>
                  <span className="text-[11px] text-[#718096] block mt-1">Target mid-to-prime tier</span>
                </div>

                <div className="bg-[#0B1423] p-5 rounded-xl border border-[#1E3352]">
                  <span className="text-xs text-[#718096] block mb-1">Est. Gross Fee Income</span>
                  <span className="text-2xl sm:text-3xl font-bold text-[#0E827C] font-mono">£66.3k</span>
                  <span className="text-[11px] text-[#0E827C] block mt-1">Per month pipeline value</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
