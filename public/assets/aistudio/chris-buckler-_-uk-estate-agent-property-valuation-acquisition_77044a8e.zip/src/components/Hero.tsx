import React from 'react';
import { Calendar, CheckCircle2, ArrowRight, ShieldCheck, MapPin, Clock, Home } from 'lucide-react';

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-[#0E827C]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-20 right-10 w-[400px] h-[350px] bg-[#C9A66B]/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Unboxed breadcrumb kicker */}
        <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-6">
          <span>UK Estate Agency Client Acquisition</span>
          <span aria-hidden="true">·</span>
          <span>Property Valuation Generation</span>
          <span aria-hidden="true">·</span>
          <span>Territory Exclusive</span>
        </div>

        {/* 2-Column Desktop Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#F8F7F3] leading-[1.12]">
              More Property Valuations.{' '}
              <span className="font-editorial italic font-normal text-[#C9A66B] block mt-1">
                More Opportunities to Win Instructions.
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-[#94A3B8] max-w-2xl font-normal leading-relaxed">
              Discover a smarter way to create consistent valuation opportunities, connect with local homeowners
              who are ready to sell, and scale your estate agency’s instruction pipeline.
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="px-7 py-3.5 rounded-xl bg-[#0E827C] hover:bg-[#129E97] text-white font-semibold text-base transition-all shadow-lg shadow-[#0E827C]/25 flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>Book a Discovery Call</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href="#how-it-works"
                className="px-7 py-3.5 rounded-xl bg-[#101C30] hover:bg-[#152540] border border-[#1E3352] text-[#F8F7F3] font-medium text-base transition-colors text-center flex items-center justify-center gap-2"
              >
                <span>See How It Works</span>
              </a>
            </div>

            {/* Micro credibility indicator */}
            <div className="pt-4 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-[#718096]">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#0E827C]" />
                <span>Zero long-term tie-ins</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0E827C]" />
                <span>Pre-qualified local sellers</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#0E827C]" />
                <span>Targeted strictly to your postcodes</span>
              </div>
            </div>
          </div>

          {/* Right Column: High-Impact Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#1E3352] shadow-2xl bg-[#101C30] group">
              {/* Primary High-Resolution Property Visual */}
              <div className="aspect-[4/3] sm:aspect-[16/11] relative overflow-hidden">
                <img
                  src="/src/assets/images/hero_uk_luxury_home_1792503663830.jpg"
                  alt="High-value British residential townhouse valuation opportunity"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1423] via-[#0B1423]/40 to-transparent" />

                {/* Overlaid Live Appointment Tag */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs">
                  <div className="bg-[#101C30]/90 backdrop-blur-md border border-[#1E3352] px-3 py-1.5 rounded-lg flex items-center gap-2 text-[#F8F7F3]">
                    <span className="w-2 h-2 rounded-full bg-[#0E827C]" />
                    <span className="font-medium">Market Appraisal Booked</span>
                  </div>
                  <span className="bg-[#0B1423]/80 backdrop-blur-md px-2.5 py-1 rounded text-[#C9A66B] font-mono text-xs">
                    KT11 Postcode
                  </span>
                </div>
              </div>

              {/* Bottom Card Context: Valuation Appointment Dossier */}
              <div className="p-5 bg-[#101C30] border-t border-[#1E3352] space-y-3.5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-base font-semibold text-[#F8F7F3]">
                      4-Bedroom Detached Country House
                    </h3>
                    <p className="text-xs text-[#718096] flex items-center gap-1.5 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-[#0E827C]" />
                      <span>Cobham, Surrey · Guide Price £1,350,000</span>
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-[#718096] block">Est. Agency Fee (1.5%)</span>
                    <span className="text-sm font-bold text-[#C9A66B] font-mono">£20,250</span>
                  </div>
                </div>

                {/* Key Seller Information Pills */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-[#0B1423] border border-[#1E3352]/70 rounded-lg p-2 flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-[#0E827C] shrink-0" />
                    <div>
                      <span className="text-[#718096] block text-[10px]">Seller Timeline</span>
                      <span className="text-[#F8F7F3] font-medium">Looking to list in 30 days</span>
                    </div>
                  </div>
                  <div className="bg-[#0B1423] border border-[#1E3352]/70 rounded-lg p-2 flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-[#C9A66B] shrink-0" />
                    <div>
                      <span className="text-[#718096] block text-[10px]">Appraisal Date</span>
                      <span className="text-[#F8F7F3] font-medium">Thursday, 10:30 AM</span>
                    </div>
                  </div>
                </div>

                <div className="text-xs text-[#94A3B8] bg-[#0E827C]/10 border border-[#0E827C]/30 rounded-lg p-2.5 flex items-center justify-between">
                  <span>Vendor requested your agency for valuation pitch</span>
                  <span className="text-[#0E827C] font-semibold">Ready in Diary</span>
                </div>
              </div>
            </div>

            {/* Floating Floating Accent Badge */}
            <div className="hidden sm:flex absolute -bottom-6 -left-6 bg-[#0E1A2B]/95 backdrop-blur-md border border-[#1E3352] p-3.5 rounded-xl shadow-xl items-center gap-3 max-w-[280px]">
              <div className="w-10 h-10 rounded-lg bg-[#0E827C]/20 border border-[#0E827C]/40 flex items-center justify-center text-[#0E827C] shrink-0">
                <Home className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <span className="text-[#F8F7F3] font-semibold block">Instruction Pipeline</span>
                <span className="text-[#718096]">Consistent valuations with local homeowners</span>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Proof & Metric Strip below Hero Split */}
        <div className="mt-16 sm:mt-24 pt-8 border-t border-[#1E3352]/80">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            <div className="space-y-1">
              <span className="text-2xl sm:text-3xl font-bold text-[#F8F7F3] font-mono tabular-nums">
                15+ Years
              </span>
              <p className="text-xs sm:text-sm text-[#718096]">
                UK property industry & valuation acquisition expertise
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-2xl sm:text-3xl font-bold text-[#0E827C] font-mono tabular-nums">
                Direct to Diary
              </span>
              <p className="text-xs sm:text-sm text-[#718096]">
                Confirmed physical market appraisals ready for your team
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-2xl sm:text-3xl font-bold text-[#C9A66B] font-mono tabular-nums">
                Postcode Exclusive
              </span>
              <p className="text-xs sm:text-sm text-[#718096]">
                Dedicated territory protection — we only partner with one agency per patch
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-2xl sm:text-3xl font-bold text-[#F8F7F3] font-mono tabular-nums">
                Zero Cold Calling
              </span>
              <p className="text-xs sm:text-sm text-[#718096]">
                Genuine inbound homeowner interest, ready for a professional appraisal
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
