import React from 'react';
import { Target, CheckCircle, CalendarCheck, Users, ShieldAlert, ArrowRight } from 'lucide-react';

interface SolutionSectionProps {
  onOpenBooking: () => void;
}

export const SolutionSection: React.FC<SolutionSectionProps> = ({ onOpenBooking }) => {
  const pillars = [
    {
      icon: Target,
      title: 'Targeted Local Seller Engagement',
      text: 'We identify homeowners within your exact operating postcodes who are actively preparing to move or re-evaluating their property equity.',
    },
    {
      icon: Users,
      title: 'Pre-Appraisal Qualification',
      text: 'Every prospective seller is vetted for genuine selling intent, property type, and realistic timeline before an appointment is requested.',
    },
    {
      icon: CalendarCheck,
      title: 'Booked Directly into Your Calendar',
      text: 'Homeowners select verified appointment slots that fit your team’s schedule, complete with property specifications and vendor motivation notes.',
    },
  ];

  return (
    <section id="solution" className="py-20 sm:py-28 bg-[#0B1423] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Visual Appraisal Showcase */}
          <div className="lg:col-span-6 relative order-2 lg:order-1">
            <div className="relative rounded-2xl overflow-hidden border border-[#1E3352] shadow-2xl bg-[#101C30]">
              <div className="aspect-[4/3] relative">
                <img
                  src="/src/assets/images/uk_property_valuation_scene_1792503664904.jpg"
                  alt="UK Property Market Appraisal Consultation Preparation"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1423] via-transparent to-black/20" />
              </div>

              {/* Overlaid Property Appraisal Dossier Preview */}
              <div className="p-6 bg-[#101C30] border-t border-[#1E3352] space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wider text-[#C9A66B] font-semibold">
                    Homeowner Appraisal Dossier
                  </span>
                  <span className="text-xs text-[#0E827C] font-mono bg-[#0E827C]/15 px-2.5 py-0.5 rounded-full border border-[#0E827C]/30">
                    Slot Confirmed
                  </span>
                </div>

                <div className="space-y-1.5">
                  <h4 className="text-base font-bold text-[#F8F7F3]">
                    The Old Vicarage, High Street, Oxshott (KT22)
                  </h4>
                  <p className="text-xs text-[#94A3B8]">
                    5-Bed Detached Victorian Residence · Approx. 3,850 sq ft · Private Grounds
                  </p>
                </div>

                <div className="bg-[#0B1423] rounded-xl p-3 border border-[#1E3352] text-xs space-y-2">
                  <div className="flex justify-between items-center text-[#94A3B8]">
                    <span>Vendor Goal:</span>
                    <span className="text-[#F8F7F3] font-medium">Downsizing; seeking advice on autumn launch</span>
                  </div>
                  <div className="flex justify-between items-center text-[#94A3B8]">
                    <span>Ownership Tenure:</span>
                    <span className="text-[#F8F7F3] font-medium">18 Years</span>
                  </div>
                  <div className="flex justify-between items-center text-[#94A3B8]">
                    <span>Expected Guide Bracket:</span>
                    <span className="text-[#C9A66B] font-mono font-semibold">£1,850,000 – £2,100,000</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-[#718096] pt-1">
                  <span>Valuer Assigned: Head of Residential</span>
                  <span>Confirmation SMS & Email Dispatched</span>
                </div>
              </div>
            </div>

            {/* Decorative trust highlight */}
            <div className="mt-4 flex items-center gap-2 text-xs text-[#718096]">
              <ShieldAlert className="w-4 h-4 text-[#C9A66B] shrink-0" />
              <span>We do not resell leads. Inquiries are exclusively captured for your agency.</span>
            </div>
          </div>

          {/* Right Column: Narrative & Framework */}
          <div className="lg:col-span-6 space-y-6 order-1 lg:order-2">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide">
              <span>The Systematic Approach</span>
              <span aria-hidden="true">·</span>
              <span>Predictable Instructions</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
              A Direct Pipeline to{' '}
              <span className="font-editorial italic font-normal text-[#C9A66B]">
                Motivated Local Homeowners.
              </span>
            </h2>

            <p className="text-base sm:text-lg text-[#94A3B8] leading-relaxed">
              Chris Buckler works with ambitious UK estate agency principals to implement a dedicated, 
              high-calibre homeowner acquisition strategy that books physical valuation appointments directly into your calendar.
            </p>

            <div className="space-y-4 pt-2">
              {pillars.map((pillar) => {
                const Icon = pillar.icon;
                return (
                  <div key={pillar.title} className="flex gap-4 p-4 rounded-xl bg-[#101C30] border border-[#1E3352]/70">
                    <div className="w-10 h-10 rounded-lg bg-[#0E827C]/20 border border-[#0E827C]/40 flex items-center justify-center text-[#0E827C] shrink-0 mt-0.5">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-[#F8F7F3]">{pillar.title}</h3>
                      <p className="text-xs sm:text-sm text-[#94A3B8] mt-1 leading-relaxed">
                        {pillar.text}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 flex items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3 rounded-xl bg-[#0E827C] hover:bg-[#129E97] text-white font-semibold text-sm transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-[#0E827C]/20"
              >
                <span>Check Territory Availability</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
