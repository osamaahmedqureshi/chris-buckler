import React, { useState } from 'react';
import { ChevronDown, HelpCircle, ArrowRight } from 'lucide-react';

interface FaqSectionProps {
  onOpenBooking: () => void;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ onOpenBooking }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'Who is this valuation acquisition service specifically suitable for?',
      answer:
        'This service is designed specifically for UK estate agency owners, managing directors, branch partners, and self-employed associate brokers who want to increase their monthly valuation numbers and win more instructions. Whether you run a single-branch independent firm or a multi-office regional network, we tailor the target volumes to your team’s valuer capacity.',
    },
    {
      question: 'How does the initial 1-to-1 Discovery Call work?',
      answer:
        'The Discovery Call is a focused, 20-minute Zoom conversation directly with Chris Buckler. We review your current instruction pipeline, check the availability of your target postcodes, and assess how many motivated local vendors are active in your area. There is zero hard selling; it is an honest feasibility assessment.',
    },
    {
      question: 'Do you offer postcode territory exclusivity?',
      answer:
        'Yes, absolutely. We operate on a strict territory exclusivity model. We will never partner with multiple competing estate agencies in the same core postal sectors. When you secure your territory, all homeowner inquiries generated within those sectors are channelled exclusively to your agency.',
    },
    {
      question: 'Can independent estate agencies and single-branch practices enquire?',
      answer:
        'Yes. In fact, independent estate agents often see the highest return because our system levels the playing field against large corporate chains with huge corporate marketing budgets. You receive pre-qualified appraisal bookings directly into your diary, allowing your personal expertise and local service to shine.',
    },
    {
      question: 'How does this compare to traditional portal leads or leaflet drops?',
      answer:
        'Leaflet drops have notoriously low response rates (often less than 0.1%) and portal automated valuation widgets attract casual browsers checking property prices with no actual intention to sell. Our approach targets motivated homeowners who actively request a professional physical appraisal from your agency, with full details and verified timelines.',
    },
    {
      question: 'What happens after we book a call or decide to proceed?',
      answer:
        'Following our initial call, we confirm your postcode exclusivity and configure your agency profile, property criteria, and valuer diary calendar. Once launched, vetted valuation appointments begin populating your schedule with full vendor briefing packs sent ahead of each visit.',
    },
  ];

  return (
    <section id="faq" className="py-20 sm:py-28 bg-[#0E1A2B] border-t border-[#1E3352]/70 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="flex items-center justify-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide">
            <span>Got Questions?</span>
            <span aria-hidden="true">·</span>
            <span>Clear Answers for UK Agency Owners</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
            Frequently Asked{' '}
            <span className="font-editorial italic font-normal text-[#C9A66B]">
              Questions.
            </span>
          </h2>
          <p className="text-base text-[#94A3B8]">
            Everything you need to know about partnering with Chris Buckler to scale your valuation appointments.
          </p>
        </div>

        {/* Accordion Container */}
        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={faq.question}
                className="bg-[#101C30] border border-[#1E3352] rounded-xl overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                  className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 cursor-pointer hover:bg-[#132238] transition-colors"
                >
                  <span className="text-base sm:text-lg font-semibold text-[#F8F7F3]">
                    {faq.question}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-lg bg-[#0B1423] border border-[#1E3352] flex items-center justify-center text-[#C9A66B] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-[#0E827C]' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-6 pt-1 sm:px-6 text-sm sm:text-base text-[#94A3B8] leading-relaxed border-t border-[#1E3352]/50">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* FAQ Bottom Callout */}
        <div className="mt-12 text-center p-6 bg-[#101C30] border border-[#1E3352] rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="text-base font-semibold text-white">Have a specific question about your territory?</h4>
            <p className="text-xs text-[#94A3B8]">Chris will personally answer during your 20-minute strategy call.</p>
          </div>
          <button
            onClick={onOpenBooking}
            className="px-5 py-2.5 rounded-lg bg-[#0E827C] hover:bg-[#129E97] text-white text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors"
          >
            Ask Chris Directly
          </button>
        </div>
      </div>
    </section>
  );
};
