import React, { useState } from 'react';
import { X, Calendar, Clock, CheckCircle2, Building2, MapPin, ArrowRight } from 'lucide-react';
import type { BookingFormState } from '../types';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialInterest?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, initialInterest }) => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [form, setForm] = useState<BookingFormState>({
    fullName: '',
    agencyName: '',
    email: '',
    phone: '',
    targetPostcodes: '',
    agencyType: 'Independent (1–2 Branches)',
    currentValuationsPerMonth: '5–10',
    targetValuationsPerMonth: '20+',
    preferredDate: '',
    preferredTime: '10:00 AM',
    notes: initialInterest || '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!isOpen) return null;

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!form.fullName.trim()) errs.fullName = 'Please enter your full name';
    if (!form.agencyName.trim()) errs.agencyName = 'Please enter your agency name';
    if (!form.email.trim() || !form.email.includes('@')) errs.email = 'Please enter a valid business email';
    if (!form.phone.trim() || form.phone.length < 9) errs.phone = 'Please enter a valid UK contact number';
    if (!form.targetPostcodes.trim()) errs.targetPostcodes = 'Please specify at least one target postcode territory';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitted(true);
  };

  const resetAndClose = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0B1423]/80 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-2xl bg-[#101C30] border border-[#1E3352] rounded-2xl shadow-2xl p-6 sm:p-8 text-[#F8F7F3] my-8"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        <button
          onClick={resetAndClose}
          className="absolute top-5 right-5 text-[#718096] hover:text-[#F8F7F3] p-1.5 rounded-lg transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          <div className="py-8 text-center space-y-5">
            <div className="w-16 h-16 mx-auto rounded-full bg-[#0E827C]/20 border border-[#0E827C] flex items-center justify-center text-[#0E827C]">
              <CheckCircle2 className="w-9 h-9" />
            </div>
            <div className="space-y-2">
              <span className="text-xs uppercase tracking-wider text-[#C9A66B] font-semibold">Discovery Session Reserved</span>
              <h3 className="text-2xl sm:text-3xl font-bold text-[#F8F7F3]" id="modal-title">
                Discovery Call Confirmed
              </h3>
              <p className="text-sm text-[#94A3B8] max-w-md mx-auto leading-relaxed">
                Thank you, <span className="text-white font-medium">{form.fullName}</span>. Chris has received your details for{' '}
                <span className="text-white font-medium">{form.agencyName}</span> ({form.targetPostcodes}).
              </p>
            </div>

            <div className="bg-[#0B1423] border border-[#1E3352] rounded-xl p-4 text-left max-w-md mx-auto space-y-2 text-xs text-[#94A3B8]">
              <div className="flex justify-between items-center py-1 border-b border-[#1E3352]/60">
                <span className="text-[#718096]">Appointment Date & Time</span>
                <span className="text-white font-medium">{form.preferredDate || 'Earliest Available'} · {form.preferredTime}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#1E3352]/60">
                <span className="text-[#718096]">Target Postcode Territory</span>
                <span className="text-white font-medium uppercase">{form.targetPostcodes}</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-[#718096]">Next Step</span>
                <span className="text-[#0E827C] font-medium">Calendar invitation sent to {form.email}</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={resetAndClose}
                className="px-6 py-2.5 rounded-lg bg-[#0E827C] hover:bg-[#129E97] text-white text-sm font-semibold transition-colors"
              >
                Close & Return to Page
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="mb-6 space-y-1.5">
              <div className="flex items-center gap-2 text-xs text-[#C9A66B] font-medium tracking-wide">
                <span>1-to-1 Territory Strategy Call</span>
                <span aria-hidden="true">·</span>
                <span>20 Minutes via Zoom</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F8F7F3]" id="modal-title">
                Book Your Valuation Strategy Call
              </h2>
              <p className="text-sm text-[#94A3B8]">
                Discuss your local postcode territory and see how many qualified valuation opportunities your agency can unlock.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={form.fullName}
                    onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                    placeholder="e.g. James Harrington"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] placeholder-[#718096] focus:outline-none focus:border-[#0E827C] transition-colors"
                  />
                  {errors.fullName && <p className="text-xs text-rose-400 mt-1">{errors.fullName}</p>}
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Estate Agency Name *</label>
                  <input
                    type="text"
                    required
                    value={form.agencyName}
                    onChange={(e) => setForm({ ...form, agencyName: e.target.value })}
                    placeholder="e.g. Harrington & Co Residential"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] placeholder-[#718096] focus:outline-none focus:border-[#0E827C] transition-colors"
                  />
                  {errors.agencyName && <p className="text-xs text-rose-400 mt-1">{errors.agencyName}</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Direct Work Email *</label>
                  <input
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="james@harringtonresidential.co.uk"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] placeholder-[#718096] focus:outline-none focus:border-[#0E827C] transition-colors"
                  />
                  {errors.email && <p className="text-xs text-rose-400 mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Direct Mobile / Phone *</label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="07700 900123"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] placeholder-[#718096] focus:outline-none focus:border-[#0E827C] transition-colors"
                  />
                  {errors.phone && <p className="text-xs text-rose-400 mt-1">{errors.phone}</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Primary Postcode Territories *</label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={form.targetPostcodes}
                      onChange={(e) => setForm({ ...form, targetPostcodes: e.target.value })}
                      placeholder="e.g. SW19, KT11, GU2"
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] placeholder-[#718096] focus:outline-none focus:border-[#0E827C] transition-colors uppercase"
                    />
                    <MapPin className="w-4 h-4 text-[#718096] absolute right-3 top-3 pointer-events-none" />
                  </div>
                  {errors.targetPostcodes && <p className="text-xs text-rose-400 mt-1">{errors.targetPostcodes}</p>}
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Agency Structure</label>
                  <select
                    value={form.agencyType}
                    onChange={(e) => setForm({ ...form, agencyType: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] focus:outline-none focus:border-[#0E827C] transition-colors"
                  >
                    <option value="Independent (1–2 Branches)">Independent (1–2 Branches)</option>
                    <option value="Multi-Branch Regional (3+ Branches)">Multi-Branch Regional (3+ Branches)</option>
                    <option value="Self-Employed Partner / Associate">Self-Employed Partner / Associate</option>
                    <option value="Country & Prime Specialist">Country & Prime Specialist</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Preferred Date</label>
                  <div className="relative">
                    <input
                      type="date"
                      value={form.preferredDate}
                      onChange={(e) => setForm({ ...form, preferredDate: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] focus:outline-none focus:border-[#0E827C] transition-colors"
                    />
                    <Calendar className="w-4 h-4 text-[#718096] absolute right-3 top-3 pointer-events-none" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#94A3B8] mb-1">Preferred Time Slot</label>
                  <div className="relative">
                    <select
                      value={form.preferredTime}
                      onChange={(e) => setForm({ ...form, preferredTime: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] focus:outline-none focus:border-[#0E827C] transition-colors"
                    >
                      <option value="09:30 AM">09:30 AM GMT</option>
                      <option value="11:00 AM">11:00 AM GMT</option>
                      <option value="02:00 PM">02:00 PM GMT</option>
                      <option value="04:30 PM">04:30 PM GMT</option>
                    </select>
                    <Clock className="w-4 h-4 text-[#718096] absolute right-3 top-3 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94A3B8] mb-1">Additional Notes / Current Challenges (Optional)</label>
                <textarea
                  rows={2}
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="e.g. Wanting to add 10–15 prime valuations per month in our southern territory."
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0B1423] border border-[#1E3352] text-sm text-[#F8F7F3] placeholder-[#718096] focus:outline-none focus:border-[#0E827C] transition-colors resize-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-lg bg-[#0E827C] hover:bg-[#129E97] text-white font-semibold text-sm transition-all shadow-lg shadow-[#0E827C]/20"
                >
                  <span>Confirm Discovery Call with Chris Buckler</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-center text-[11px] text-[#718096] mt-2">
                  No obligation · Territory check included · Zero high-pressure sales
                </p>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
