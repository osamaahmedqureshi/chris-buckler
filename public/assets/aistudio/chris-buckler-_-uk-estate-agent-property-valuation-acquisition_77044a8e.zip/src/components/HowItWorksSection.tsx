import React, { useState } from 'react';
import { Search, Compass, MessageSquare, CalendarCheck, Check } from 'lucide-react';

interface HowItWorksSectionProps {
  onOpenBooking: () => void;
}

export const HowItWorksSection: React.FC<HowItWorksSectionProps> = ({ onOpenBooking }) => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    {
      number: '01',
      title: 'Understand Your Agency & Territory',
      subtitle: 'Mapping your target postcodes, property price brackets, and fee models.',
      description:
        'We begin by analysing your local UK territory, your existing market share, average sale values, and the specific property types (e.g. £750k+ family residences, period cottages, modern apartments) you want to win.',
      deliverables: [
        'Postcode territory audit and exclusivity check',
        'Target vendor persona and property bracket alignment',
        'Valuer capacity and calendar integration review',
      ],
      icon: Search,
    },
    {
      number: '02',
      title: 'Develop Your Valuation Acquisition Strategy',
      subtitle: 'Crafting bespoke local marketing campaigns tailored to homeowners in your area.',
      description:
        'Rather than generic corporate branding, we deploy highly targeted campaigns that speak directly to local homeowners considering selling, highlighting the tangible advantage of choosing your agency.',
      deliverables: [
        'Hyper-local homeowner acquisition campaigns',
        'Targeted digital and social appraisal funnels',
        'Compelling, high-trust valuation proposition',
      ],
      icon: Compass,
    },
    {
      number: '03',
      title: 'Connect & Pre-Qualify Potential Sellers',
      subtitle: 'Filtering genuine prospective vendors from passive valuation curious browsers.',
      description:
        'When local homeowners respond, our qualification process confirms their selling timeline, reason for moving, property attributes, and intent to instruct before an appointment is offered.',
      deliverables: [
        'Timeline and motivation verification (30–90 day movers)',
        'Full property specification gathering',
        'Elimination of tyre-kickers and automated spam',
      ],
      icon: MessageSquare,
    },
    {
      number: '04',
      title: 'Create More Valuation Conversations',
      subtitle: 'Qualified appointments booked straight into your valuation diary.',
      description:
        'Your negotiators and valuers arrive at the property with full context, ready to deliver an exceptional pitch, build personal rapport, and secure the instruction at your full fee.',
      deliverables: [
        'Diary-synced appointments with SMS reminders',
        'Vendor background dossier sent ahead of the visit',
        'Consistent stream of new instruction opportunities',
      ],
      icon: CalendarCheck,
    },
  ];

  return (
    <section id="how-it-works" className="py-20 sm:py-28 bg-[#0E1A2B] border-t border-[#1E3352]/70 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-3">
            <span>The 4-Stage Framework</span>
            <span aria-hidden="true">·</span>
            <span>Structured Acquisition</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
            How It Works:{' '}
            <span className="font-editorial italic font-normal text-[#C9A66B]">
              From Territory Audit to Booked Valuation.
            </span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#94A3B8] leading-relaxed">
            A clear, transparent process built specifically for UK estate agency principals who want
            predictable instructions without adding internal headcount.
          </p>
        </div>

        {/* 4 Interactive Connected Steps */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Step Selector Column */}
          <div className="lg:col-span-5 space-y-3">
            {steps.map((step, idx) => {
              const isSelected = activeStep === idx;
              return (
                <button
                  key={step.number}
                  onClick={() => setActiveStep(idx)}
                  className={`w-full text-left p-5 rounded-xl border transition-all duration-200 cursor-pointer ${
                    isSelected
                      ? 'bg-[#101C30] border-[#0E827C] shadow-lg shadow-[#0E827C]/10'
                      : 'bg-[#0B1423]/70 border-[#1E3352]/70 hover:border-[#1E3352] hover:bg-[#0B1423]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-xs font-mono font-bold ${
                        isSelected ? 'text-[#0E827C]' : 'text-[#718096]'
                      }`}
                    >
                      {step.number}
                    </span>
                    {isSelected && (
                      <span className="text-[11px] text-[#C9A66B] uppercase font-semibold tracking-wider">
                        Active Stage
                      </span>
                    )}
                  </div>
                  <h3
                    className={`text-base font-bold transition-colors ${
                      isSelected ? 'text-white' : 'text-[#94A3B8]'
                    }`}
                  >
                    {step.title}
                  </h3>
                  <p className="text-xs text-[#718096] mt-1 line-clamp-1">
                    {step.subtitle}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Step Detailed View Column */}
          <div className="lg:col-span-7 bg-[#101C30] border border-[#1E3352] rounded-2xl p-7 sm:p-9 shadow-xl relative min-h-[380px] flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-[#1E3352]/70 pb-5">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[#0B1423] border border-[#1E3352] flex items-center justify-center text-[#C9A66B]">
                    {React.createElement(steps[activeStep].icon, { className: 'w-6 h-6' })}
                  </div>
                  <div>
                    <span className="text-xs font-mono text-[#0E827C] uppercase tracking-wider block">
                      Stage {steps[activeStep].number} of 04
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold text-[#F8F7F3]">
                      {steps[activeStep].title}
                    </h3>
                  </div>
                </div>
              </div>

              <p className="text-sm sm:text-base text-[#94A3B8] leading-relaxed">
                {steps[activeStep].description}
              </p>

              <div className="space-y-3 pt-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#C9A66B] block">
                  Key Deliverables & Action Items:
                </span>
                <div className="space-y-2">
                  {steps[activeStep].deliverables.map((item) => (
                    <div key={item} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#F8F7F3]">
                      <div className="w-4 h-4 rounded-full bg-[#0E827C]/20 text-[#0E827C] flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3 h-3" />
                      </div>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-[#1E3352]/70 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
              <span className="text-[#718096]">
                Steps are customised to your agency's territory capacity
              </span>
              <button
                onClick={onOpenBooking}
                className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-[#0E827C] hover:bg-[#129E97] text-white font-semibold transition-colors cursor-pointer"
              >
                Discuss Your Postcodes
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
