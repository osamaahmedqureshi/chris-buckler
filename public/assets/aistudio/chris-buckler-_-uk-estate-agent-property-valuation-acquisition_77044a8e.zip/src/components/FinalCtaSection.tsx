import React from 'react';
import { ArrowRight, ShieldCheck, Calendar, Phone, Mail, MapPin } from 'lucide-react';

interface FinalCtaSectionProps {
  onOpenBooking: () => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({ onOpenBooking }) => {
  return (
    <section className="py-24 sm:py-32 bg-[#0B1423] relative overflow-hidden">
      {/* Background radial teal & gold glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-[#0E827C]/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[300px] h-[300px] bg-[#C9A66B]/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        {/* Unboxed breadcrumb kicker */}
        <div className="flex items-center justify-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-6">
          <span>Confidential Territory Review</span>
          <span aria-hidden="true">·</span>
          <span>Limited to 1 Agency Per Patch</span>
        </div>

        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#F8F7F3] leading-[1.15]">
          Ready to Start More{' '}
          <span className="font-editorial italic font-normal text-[#C9A66B] block sm:inline">
            Valuation Conversations?
          </span>
        </h2>

        <p className="mt-6 text-base sm:text-xl text-[#94A3B8] max-w-2xl mx-auto leading-relaxed">
          Let’s explore how your estate agency could create more consistent opportunities to connect with 
          local homeowners and win high-margin instructions in your key postcodes.
        </p>

        {/* Action Button Container */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onOpenBooking}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[#0E827C] hover:bg-[#129E97] text-white font-bold text-base transition-all shadow-xl shadow-[#0E827C]/30 flex items-center justify-center gap-2.5 cursor-pointer group"
          >
            <Calendar className="w-5 h-5 text-white/90" />
            <span>Book Your Discovery Call with Chris</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Guarantees */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-y-2 gap-x-8 text-xs text-[#718096]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#0E827C]" />
            <span>Strict Postcode Exclusivity</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C9A66B]" />
            <span>Direct 20-minute strategy session with Chris</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#0E827C]" />
            <span>Zero hard-sell or generic retainers</span>
          </div>
        </div>

        {/* Direct Contact strip */}
        <div className="mt-14 pt-8 border-t border-[#1E3352]/70 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-[#94A3B8] max-w-2xl mx-auto">
          <div className="flex items-center justify-center gap-2">
            <MapPin className="w-4 h-4 text-[#C9A66B]" />
            <span>London & UK Nationwide Coverage</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <Mail className="w-4 h-4 text-[#0E827C]" />
            <span>enquiries@chrisbuckler.co.uk</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <Phone className="w-4 h-4 text-[#DFBA7D]" />
            <span>Direct Consultation by Invitation</span>
          </div>
        </div>
      </div>
    </section>
  );
};
