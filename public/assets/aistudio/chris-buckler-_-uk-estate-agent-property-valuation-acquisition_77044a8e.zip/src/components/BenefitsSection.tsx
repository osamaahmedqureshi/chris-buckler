import React from 'react';
import { Calendar, UserCheck, Clock, TrendingUp, Award, Compass } from 'lucide-react';

export const BenefitsSection: React.FC = () => {
  const benefits = [
    {
      icon: Calendar,
      title: 'More Valuation Opportunities',
      description:
        'Fill your diary with genuine homeowner appraisals rather than sitting back and hoping for incoming calls from portals or passing high-street footfall.',
      metric: 'Consistent Diary',
      colSpan: 'md:col-span-2',
      highlight: true,
    },
    {
      icon: UserCheck,
      title: 'Stronger Seller Engagement',
      description:
        'Homeowners who have expressed direct interest in your agency and have already provided their moving timeline are significantly warmer to pitch.',
      metric: 'Warm Inbound',
      colSpan: 'md:col-span-1',
    },
    {
      icon: Clock,
      title: 'Reduced Prospecting Pressure',
      description:
        'Free your senior staff and listing negotiators from tedious cold prospecting and door-knocking so they can concentrate on pitching and winning.',
      metric: 'Time Reclaimed',
      colSpan: 'md:col-span-1',
    },
    {
      icon: TrendingUp,
      title: 'Predictable Pipeline Development',
      description:
        'Build a visible horizon of active sellers 30, 60, and 90 days out, allowing you to plan revenue and resource allocation with real confidence.',
      metric: 'Future Visibility',
      colSpan: 'md:col-span-2',
      highlight: true,
    },
    {
      icon: Award,
      title: 'More Time to Win Instructions',
      description:
        'With valuation appointments reliably scheduled, your team can spend more time refining marketing proposals, local market comparables, and presentation packs.',
      metric: 'Higher Conversion',
      colSpan: 'md:col-span-1',
    },
    {
      icon: Compass,
      title: 'A Clearer Route to Agency Growth',
      description:
        'Whether you want to dominate one core postal code or expand into neighbouring market towns, a reliable valuation acquisition framework powers scalable expansion.',
      metric: 'Scalable Growth',
      colSpan: 'md:col-span-2',
    },
  ];

  return (
    <section id="benefits" className="py-20 sm:py-28 bg-[#0B1423] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide mb-3">
            <span>Commercial Advantage</span>
            <span aria-hidden="true">·</span>
            <span>UK Agency Impact</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
            More Conversations. More Opportunities.{' '}
            <span className="font-editorial italic font-normal text-[#C9A66B]">
              More Room to Grow.
            </span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#94A3B8] leading-relaxed">
            By systemising the way your estate agency attracts and secures valuation appointments, 
            you unlock time, consistency, and competitive dominance in your patch.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {benefits.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className={`${item.colSpan} bg-[#101C30] border border-[#1E3352] rounded-2xl p-7 sm:p-8 hover:border-[#0E827C]/60 transition-all duration-300 flex flex-col justify-between group`}
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-xl bg-[#0B1423] border border-[#1E3352] flex items-center justify-center text-[#0E827C] group-hover:text-[#C9A66B] transition-colors">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-mono text-[#718096]">
                      {item.metric}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-[#F8F7F3] mb-3">
                    {item.title}
                  </h3>

                  <p className="text-sm text-[#94A3B8] leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#1E3352]/60 flex items-center gap-2 text-xs text-[#718096]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0E827C]" />
                  <span>Direct benefit to fee-earning agency partners</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
