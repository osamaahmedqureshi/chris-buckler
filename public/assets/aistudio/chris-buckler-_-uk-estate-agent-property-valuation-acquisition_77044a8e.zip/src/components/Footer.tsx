import React from 'react';

interface FooterProps {
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  return (
    <footer className="bg-[#080E18] border-t border-[#1E3352]/80 text-[#94A3B8] py-14 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-start">
          {/* Brand info */}
          <div className="md:col-span-5 space-y-4">
            <span className="text-xl font-bold tracking-tight text-[#F8F7F3] block">
              CHRIS BUCKLER
            </span>
            <p className="text-xs sm:text-sm text-[#718096] max-w-sm leading-relaxed">
              Helping UK estate agency owners, managing directors, and independent property professionals
              generate and book more valuation appointments directly with motivated local homeowners.
            </p>
            <div className="text-xs text-[#C9A66B] font-mono">
              Associated with The Agency UK (TAUK) · London & Nationwide
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-4 grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-2.5">
              <span className="font-semibold text-white block uppercase tracking-wider text-[11px]">
                Platform
              </span>
              <ul className="space-y-2">
                <li>
                  <a href="#challenge" className="hover:text-white transition-colors">
                    The Problem
                  </a>
                </li>
                <li>
                  <a href="#solution" className="hover:text-white transition-colors">
                    The Solution
                  </a>
                </li>
                <li>
                  <a href="#how-it-works" className="hover:text-white transition-colors">
                    How It Works
                  </a>
                </li>
                <li>
                  <a href="#benefits" className="hover:text-white transition-colors">
                    Key Benefits
                  </a>
                </li>
              </ul>
            </div>

            <div className="space-y-2.5">
              <span className="font-semibold text-white block uppercase tracking-wider text-[11px]">
                Agency & Trust
              </span>
              <ul className="space-y-2">
                <li>
                  <a href="#showcase" className="hover:text-white transition-colors">
                    Valuation Portal
                  </a>
                </li>
                <li>
                  <a href="#about" className="hover:text-white transition-colors">
                    About Chris
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-white transition-colors">
                    FAQs
                  </a>
                </li>
                <li>
                  <button
                    onClick={onOpenBooking}
                    className="text-[#0E827C] hover:text-[#129E97] transition-colors cursor-pointer text-left"
                  >
                    Book Discovery Call
                  </button>
                </li>
              </ul>
            </div>
          </div>

          {/* Territory Consultation Badge */}
          <div className="md:col-span-3 bg-[#101C30] border border-[#1E3352] rounded-xl p-4 space-y-2 text-xs">
            <span className="text-[#C9A66B] font-semibold block">Postcode Exclusivity</span>
            <p className="text-[#718096] text-[11px] leading-relaxed">
              We operate a strict single-agency policy per designated territory to safeguard your local market share.
            </p>
            <button
              onClick={onOpenBooking}
              className="w-full mt-2 py-2 text-center rounded bg-[#0E827C]/20 border border-[#0E827C]/40 text-[#0E827C] hover:bg-[#0E827C] hover:text-white font-medium transition-all cursor-pointer"
            >
              Verify Your Postcode
            </button>
          </div>
        </div>

        {/* Quiet Bottom Strip */}
        <div className="mt-12 pt-8 border-t border-[#1E3352]/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#718096]">
          <p>© {new Date().getFullYear()} Chris Buckler. All rights reserved. Custom UK Estate Agency Presentation.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-white cursor-pointer">Privacy Policy</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-white cursor-pointer">Terms of Consultation</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-white cursor-pointer">Territory Agreement</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
