import React from 'react';
import { Award, ShieldCheck, CheckCircle2, Building, ArrowRight } from 'lucide-react';

interface AboutChrisSectionProps {
  onOpenBooking: () => void;
}

export const AboutChrisSection: React.FC<AboutChrisSectionProps> = ({ onOpenBooking }) => {
  return (
    <section id="about" className="py-20 sm:py-28 bg-[#0E1A2B] border-t border-[#1E3352]/70 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Portrait & Credentials */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#1E3352] shadow-2xl bg-[#101C30]">
              <div className="aspect-[4/3] sm:aspect-[4/5] relative">
                <img
                  src="/src/assets/images/chris_buckler_portrait_1792503664993.jpg"
                  alt="Chris Buckler - UK Property Industry Specialist and Agency Consultant"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1423] via-transparent to-transparent opacity-80" />
              </div>

              {/* Bottom Card Identity Banner */}
              <div className="p-5 bg-[#101C30] border-t border-[#1E3352]">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-[#F8F7F3]">Chris Buckler</h3>
                    <p className="text-xs text-[#C9A66B] font-medium">
                      UK Property Specialist & Agency Client Acquisition
                    </p>
                  </div>
                  <span className="text-xs font-mono bg-[#0B1423] text-[#0E827C] border border-[#1E3352] px-2.5 py-1 rounded">
                    15+ Yrs Industry
                  </span>
                </div>
              </div>
            </div>

            {/* Overlaid Experience Badge */}
            <div className="hidden sm:flex absolute -bottom-5 -right-5 bg-[#101C30]/95 backdrop-blur-md border border-[#1E3352] p-4 rounded-xl shadow-xl items-center gap-3 max-w-[260px]">
              <div className="w-10 h-10 rounded-lg bg-[#C9A66B]/20 border border-[#C9A66B]/40 flex items-center justify-center text-[#C9A66B] shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <span className="text-[#F8F7F3] font-semibold block">Industry Grounded</span>
                <span className="text-[#718096]">Not a generic marketing agency — real property experience</span>
              </div>
            </div>
          </div>

          {/* Right Column: Background & Philosophy */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-[#C9A66B] font-medium tracking-wide">
              <span>Personal Accountability</span>
              <span aria-hidden="true">·</span>
              <span>About Chris Buckler</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F7F3] leading-tight">
              Built by an Estate Agent,{' '}
              <span className="font-editorial italic font-normal text-[#C9A66B]">
                Specifically for Estate Agents.
              </span>
            </h2>

            <p className="text-base sm:text-lg text-[#94A3B8] leading-relaxed">
              With over 15 years in the UK property industry—including working alongside top-performing 
              brokers at The Agency UK (TAUK)—Chris understands the exact challenges agency owners face 
              every single morning: winning instructions against tough local competition.
            </p>

            <div className="space-y-4 pt-2">
              <div className="p-4 rounded-xl bg-[#101C30] border border-[#1E3352]/70 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#F8F7F3]">
                  <Building className="w-4 h-4 text-[#0E827C]" />
                  <span>Deep Knowledge of the UK Vendor Mindset</span>
                </div>
                <p className="text-xs sm:text-sm text-[#94A3B8] leading-relaxed pl-6">
                  Homeowners don't respond to corporate jargon or cheap discounts. They respond to authority, 
                  local insight, and discreet professional representation. Our campaigns reflect that premium standard.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#101C30] border border-[#1E3352]/70 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#F8F7F3]">
                  <ShieldCheck className="w-4 h-4 text-[#C9A66B]" />
                  <span>100% Territory Exclusivity Guarantee</span>
                </div>
                <p className="text-xs sm:text-sm text-[#94A3B8] leading-relaxed pl-6">
                  We never pit clients against each other. When we partner with your agency for a designated postcode territory, 
                  that territory is locked to your firm exclusively.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#101C30] border border-[#1E3352]/70 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#F8F7F3]">
                  <CheckCircle2 className="w-4 h-4 text-[#0E827C]" />
                  <span>No Fluff, No Retainers with Zero Accountability</span>
                </div>
                <p className="text-xs sm:text-sm text-[#94A3B8] leading-relaxed pl-6">
                  Everything is focused on one unambiguous metric: real homeowners opening their front door for a 
                  valuation with your estate agency.
                </p>
              </div>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3 rounded-xl bg-[#0E827C] hover:bg-[#129E97] text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#0E827C]/20"
              >
                <span>Schedule a 1-to-1 Discussion</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
